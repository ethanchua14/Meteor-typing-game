const randomWords = require('random-words');
const express = require('express');
const bodyParser = require('body-parser');
const path = require('path')

const server = express();
server.use(bodyParser.urlencoded({
    extended: false
}));
server.use(express.static('static'))


server.set('views', path.join(__dirname, 'views'))
server.set('view engine', 'pug')

let highScore = 0;

server.get('/', function(req, res){
    res.render('homepage', {
        highScore: highScore,
    })
})

server.get('/tutorial', function(req, res){
    let pathToTutorial = path.join(__dirname, 'static', 'tutorial.html')
    res.sendFile(pathToTutorial)
})

server.get('/game', function(req, res){
    let difficulty = req.query.difficulty;
    let words = randomWords(1000);

    res.render('game', {
        difficulty: difficulty,
        words: words
    })
})

server.get('/difficulty', function(req, res){
    let pathToHomepage = path.join(__dirname, 'static', 'difficulty.html')
    res.sendFile(pathToHomepage)
})

server.post('/game', function(req, res){
    let score = req.body.score

    if (score > highScore) {
        highScore = score;
    }

    res.render('results', {
        score: score,
        highScore: highScore
    })
})

server.listen(8080, function() {
    console.log("Server on port 8080");
})