// sets up the drawing area
let canvas = document.getElementById('drawingArea');
canvas.width = canvas.clientWidth;
canvas.height = canvas.clientHeight;

// retrives variable from server side
let CSSprops = getComputedStyle(document.documentElement);
let characters = CSSprops.getPropertyValue('--words')
let difficulty = CSSprops.getPropertyValue('--difficulty')

let words = characters.split(",")

let diffMultiplier;

//length of word assigned based on difficulty
let easyWords = []
let mediumWords = []
let hardWords = []
for (let i = 0; i < words.length; i++) {
    if (words[i].length <= 5) {
        easyWords.push(words[i])
    }
    else if (words[i].length >= 9) {
        hardWords.push(words[i])
    }
    else {
        mediumWords.push(words[i])
    }
}

let asteroids = [];
let asteroidCounter = 0;

let dropRate;
let dropRateRate = 0;

//difficulty changes drop speed and score multiplier
if (difficulty == 'Easy') {
    dropRate = 500;
    words = easyWords
    diffMultiplier = 1
}
else if (difficulty == 'Medium') {
    dropRate = 375;
    words = mediumWords
    diffMultiplier = 1.25
}
else if (difficulty == 'Hard') {
    dropRate = 250;
    words = hardWords
    diffMultiplier = 1.5
}
asteroidCounter = dropRate;

// sets up positioning of rocket
let rocketRow = 3;
let movementCounter = 0;

// the letter of the word you are currently on
let charCount = 0;

let score = 0;
let gameOver = false;

// asteroid class
class Asteroid {
    constructor() {
        this.row = Math.round(Math.random() * 4) + 1;
        this.image = document.getElementById("asteroidImg")
        this.width = asteroidImg.width;
        this.height = asteroidImg.height;
        this.x =  this.row * canvas.width / 6 - this.image.width / 16;
        this.y = 0;
        this.speed = 1;
        this.word = words[Math.round(Math.random() * (words.length - 1))]
        this.wasTyped = ''
        this.shoot = false;
    }
    //asteroids moves downwards each frame
    move() {
        this.y += this.speed;
    }
}

// graphics of rocket
let rocketImg = document.getElementById("rocketImg")
// rocket object
let rocket = {
    image: rocketImg,
    x: canvas.width / 2 - rocketImg.width / 2 + 25,
    y: canvas.height - rocketImg.height + 50,
    width: 100, // in pixels
    height: 100,
    speed: 0,

    // rocket moves across screen
    move: function() {
        this.x += this.speed
    }
}

//machines begins animation and listens for key press
function init() {
    window.addEventListener('keydown', handleKeyDown)
    window.requestAnimationFrame(nextFrame);
}

function nextFrame() {
    //controls when asteroids drop
    if (asteroidCounter < dropRate) {
        asteroidCounter++
        dropRateRate++
    }
    // creates asteroid
    else {
        let asteroid = new Asteroid(difficulty);
        asteroids.push(asteroid);
        asteroidCounter = 0;
    }
    // increases the rate at which asteroids fall
    if (dropRateRate > 1000) {
        if (!(dropRateRate - 50 <= 0)) {
            dropRate -= 50
        }
        dropRateRate = 0
    }
    //if asteroid hits ground, game ends
    for (let i = 0; i < asteroids.length; i++) {
        asteroids[i].move();
        if (asteroids[i].y > canvas.height) {
            gameOver = true;
            new Audio('https://rpg.hamsterrepublic.com/wiki-images/d/d7/Oddbounce.ogg').play() 
        }
    }

    //controls rocket movement
    movementCounter += Math.abs(rocket.speed)
    rocket.move();
    if (movementCounter >= canvas.width / 6) {
        movementCounter = 0;
        if (rocket.speed == 10) {
            rocketRow++
        }
        if (rocket.speed == -10) {
            rocketRow--
        }
        rocket.speed = 0;
    }

    // displays graphics
    drawNextFrame();

    // handles ending seqeunce of game
    if (gameOver) {
        handleGameOver();
    }

    // animation terminates if game is over
    if (!gameOver) {
        window.requestAnimationFrame(nextFrame);
    }
}

function handleGameOver() {
    let context = canvas.getContext('2d');

    //display game over
    context.font = '48px Times New Roman';
    context.textAlign="center";
    context.fillText('Game Over!', canvas.width/2, canvas.height/2)

    // updates score
    let scoreCount = document.getElementById('score')
    scoreCount.value = score

    // reveals "see results" form
    let form = document.getElementById('submit')
    form.style.display = 'block'
}

// animates each following frame
function drawNextFrame() {
    let context = canvas.getContext('2d');
    context.clearRect(0, 0, canvas.width, canvas.height);
    
    for (let i = 0; i < asteroids.length; i++) {
        //draw asteroid on canvas
        context.beginPath();
        context.drawImage(asteroids[i].image, asteroids[i].x, asteroids[i].y, asteroids[i].image.width/8, asteroids[i].image.height/8)
        context.fillStyle = 'white'
        context.font = "30px Times New Roman"
        context.textAlign = 'left'
        //draw asteroid word on canvas
        context.fillText(asteroids[i].word, asteroids[i].x + asteroids[i].width/16- context.measureText(asteroids[i].word).width/2, asteroids[i].y + asteroids[i].height/10)
        if(asteroids[i].shoot == true){
        //create line that shoots out of rocket
            context.beginPath();
            context.moveTo(rocket.x + rocket.width, rocket.y);
            context.setLineDash([5,15])
            context.lineTo(asteroids[i].x + asteroids[i].width/16, asteroids[i].y + asteroids[i].height/10)
            context.strokeStyle = '#FF355E'
            context.lineWidth = 5;
            context.stroke()
            asteroids[i].shoot = false;
        }
        //change asteroid word color
        context.fillStyle = 'green'
        context.fillText(asteroids[i].wasTyped, asteroids[i].x + asteroids[i].width/16 - context.measureText(asteroids[i].word).width/2, asteroids[i].y + asteroids[i].height/10)

    }

    //draw rocket
    context.beginPath();
    context.drawImage(rocket.image, rocket.x, rocket.y, rocket.width * 2, rocket.height * 2);
    
    // draw score
    context.textAlign = 'left'
    context.font = "30px Times New Roman"
    context.fillStyle = 'white'
    context.fillText("Score: " + score, 25, 50);
}

// handles typing feature and rocket movement
function handleKeyDown(evt) {
    // moves rocket on arrow key press
    if (evt.which == 37 && rocketRow !== 1 && rocket.speed == 0) {
        rocket.speed = -10
        return;
    }
    if (evt.which == 39 && rocketRow !== 5 && rocket.speed == 0) {
        rocket.speed = 10
        return;
    }
    if (evt.which == 37 || evt.which == 39) {
        return;
    }
    if (asteroids.length == 0) {
        return;
    }

    // selects the asteroids to target
    let i = 0;
    let broken = false;
    while (i < asteroids.length) {
        if (asteroids[i].row == rocketRow) {
            broken = true;
            break;
        }
        i++
    }

    if (!broken) {
        return;
    }

    // ensures rocket is in correct row
    if (asteroids[i].row !== rocketRow) {
        return;
    }

    // handles typing of word
    if (evt.key == asteroids[i].word[charCount]) {
        new Audio('http://codeskulptor-demos.commondatastorage.googleapis.com/GalaxyInvaders/alien_shoot.wav').play() 
        asteroids[i].wasTyped = asteroids[i].wasTyped + evt.key 
        asteroids[i].shoot = true;
        if (charCount < asteroids[i].word.length - 1) {
            charCount++
        }
        else {
            charCount = 0;
            score += 100 * diffMultiplier * asteroids[i].word.length
            asteroids.splice(i, 1);
            new Audio('http://codeskulptor-demos.commondatastorage.googleapis.com/GalaxyInvaders/explosion_02.wav').play() 
        }
    }
}

window.onload = init;